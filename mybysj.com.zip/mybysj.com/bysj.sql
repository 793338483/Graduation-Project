-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2017-05-13 03:07:36
-- 服务器版本： 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bysj`
--

-- --------------------------------------------------------

--
-- 表的结构 `bs_admin_user`
--

CREATE TABLE `bs_admin_user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `bs_admin_user`
--

INSERT INTO `bs_admin_user` (`id`, `username`, `password`) VALUES
(1, 'admin', '123456');

-- --------------------------------------------------------

--
-- 表的结构 `bs_album`
--

CREATE TABLE `bs_album` (
  `id` int(5) NOT NULL,
  `albumname` varchar(64) CHARACTER SET utf8 NOT NULL,
  `albumimg` varchar(300) CHARACTER SET utf8 NOT NULL,
  `userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `bs_album`
--

INSERT INTO `bs_album` (`id`, `albumname`, `albumimg`, `userID`) VALUES
(4, '图片展示', 'Public/Uploads/Albums/2017-05-05/590c714d75823.png', 1),
(5, 'test1', 'Public/Uploads/Albums/2017-05-05/590c726bb2258.png', 10001),
(6, 'test5', 'Public/Uploads/Albums/2017-05-07/590ec11bc6e22.png', 10006),
(9, 'test11', 'Public/Uploads/Albums/2017-05-07/590ecb2f67e56.png', 10009);

-- --------------------------------------------------------

--
-- 表的结构 `bs_blog`
--

CREATE TABLE `bs_blog` (
  `id` int(5) NOT NULL,
  `blog_title` varchar(64) CHARACTER SET utf8 NOT NULL,
  `blog_img` varchar(255) CHARACTER SET utf8 NOT NULL,
  `blog_zhaiyao` varchar(500) CHARACTER SET utf8 NOT NULL,
  `blog_content` text CHARACTER SET utf8 NOT NULL,
  `addtime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `bs_blog`
--

INSERT INTO `bs_blog` (`id`, `blog_title`, `blog_img`, `blog_zhaiyao`, `blog_content`, `addtime`) VALUES
(3, '北京', 'Public/Uploads/Blog/2017-05-06/590dc001620f7.jpg', '魅力时代', '&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dbff185f8c.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dbff18c136.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dbff18f3fe.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dbff194608.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dbff197cb8.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dbff19ab99.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '2017-05-06 20:22:25'),
(1001, '奖项', 'Public/Uploads/Blog/', '本店摄影师获奖情况', '&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;推崇自然光拍摄，无论流行的风格如何变化，保留原始氛围的自然瞬间都容易引起主人公情感上的共鸣，能穿越岁月，雕刻时光。倡导不过度后期。注重的依旧是不可复制的瞬间，不求超广角以及深度后期的视觉刺激，倾向于用平实的镜头语言传递爱的光芒。&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc54386eca.jpg&quot; title=&quot;&quot; alt=&quot;20150808-141.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;12th Place（WPJA Q3 2015, Touch）&amp;nbsp;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img class=&quot;aligncenter&quot; src=&quot;http://leonwongphoto.com/blog/wp-content/uploads/2015/07/1436502408_thumb.jpeg&quot; alt=&quot;&quot; width=&quot;800&quot; height=&quot;533&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;4th Place（WPJA Q2 2015, Reception）&amp;nbsp;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&lt;/strong&gt;&amp;nbsp;This was an image favorite of mine at first sight and a good example of the scene and the image generously sharing light and color in a blend of smooth composition. Photos like this become the moment before our eyes by transporting us to more than the obvious via a mix of scene and excellent “seeing” by the photographer.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc56fc29fd.jpg&quot; title=&quot;&quot; alt=&quot;LW11936-blog.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;5th Place（WPJA Q4 2014, Mirrors）&amp;nbsp;&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&lt;/strong&gt;&amp;nbsp;This is a warm and inviting image that uses the entire frame to provide a narrative of visual information. The stark countertop merely adds to the intrigue, providing a second layer of the story without distraction.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc580ee524.jpg&quot; title=&quot;&quot; alt=&quot;201408-09-USA-205.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;20th Place（ISPWP Fall 2014, Framing The Subject）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc5964b888.jpg&quot; title=&quot;&quot; alt=&quot;LEON2659.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;6th Place（ISPWP Summer 2014, Wedding Details）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc5a680fb7.jpg&quot; title=&quot;&quot; alt=&quot;20130728265.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;12th Place（AGWPJA Q3 2013, Reception Ambiance）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc5bb35197.jpg&quot; title=&quot;&quot; alt=&quot;20130728226.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;13th Place（ISPWP Fall 2013, Venue or Location）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc5d0d705e.jpg&quot; title=&quot;&quot; alt=&quot;blog_2013012425.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;3rd Place（WPJA Q2 2013, Emotion）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&lt;/strong&gt;&amp;nbsp;Unexpected perspective. Nice moment. Emotion carries it.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&amp;nbsp;&lt;/strong&gt;A nice moment, shot from inside the car, framing the contrasts of emotion between the bride and person outside.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc5e0b7c02.jpg&quot; title=&quot;&quot; alt=&quot;blog_ORE1065.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;5th Place（WPJA Q2 2013, Lit Portrait）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&lt;/strong&gt;&amp;nbsp;Nice framing with the bride and groom against the evening lights of the city. It gives me a little feeling of vertigo.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc5ed233de.jpg&quot; title=&quot;&quot; alt=&quot;20130105140.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;1st Place（WPJA Q1 2013, Weather）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&lt;/strong&gt;&amp;nbsp;The water droplets juxtaposed with the bride’s smile made this photo a great moment.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&amp;nbsp;&lt;/strong&gt;The contrast of the cool exterior light and the warmth of the yellow interior light emphasizes the chill of winter. The bride looks beautiful and unfazed by the bad weather. Nice moment.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&amp;nbsp;&lt;/strong&gt;Beautiful expression of a bride who won’t let rain affect her day.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc5fdb539c.jpg&quot; title=&quot;&quot; alt=&quot;20130124230.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;4th Place（WPJA Q1 2013, Ceremony）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&amp;nbsp;&lt;/strong&gt;Loved looking at the emotions on the bridesmaids faces, with only one fighting away tears. Their dresses complimented the the draping of the background which added the the visual appeal.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc60b2946c.jpg&quot; title=&quot;&quot; alt=&quot;2013010323572.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;11th Place（WPJA Q1 2013, Weather）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc624220e8.jpg&quot; title=&quot;&quot; alt=&quot;g20123159755.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;15th Place（WPJA Q1 2013, Getting Ready）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc635ebf74.jpg&quot; title=&quot;&quot; alt=&quot;20121021-138.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;5th Place（AGWPJA Q4 2012, Kids）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;Judges Comment:&lt;/strong&gt;&amp;nbsp;The little girl has a great expression that is framed perfectly by the kissing couple. I applaud the photographer for looking past the obvious kissing picture to see the little girl.&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc64c6e0f2.jpg&quot; title=&quot;&quot; alt=&quot;EON3390.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;4th Place（ISPWP Winter 2012, Venue or Location）&lt;/strong&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-06/590dc6adaea65.jpg&quot; title=&quot;&quot; alt=&quot;EON1369.jpg&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;border: 0px; font-family: &amp;quot;Helvetica Neue&amp;quot;, Helvetica, Arial, sans-serif; font-size: 15px; margin-top: 0px; margin-bottom: 1.625em; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed; color: rgb(55, 55, 55); line-height: 19.5px; white-space: normal; widows: 1; text-align: center; background-color: rgb(239, 239, 238);&quot;&gt;&lt;strong style=&quot;border: 0px; font-family: inherit; font-style: inherit; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; table-layout: fixed;&quot;&gt;12th Place（WPJA Q3 2012, Lit Portrait）&lt;/strong&gt;&lt;/p&gt;', '2017-05-06 20:52:22'),
(1002, '明珠风情 巴厘岛旅拍', 'Public/Uploads/Blog/2017-05-07/590e69e2a2f64.jpg', '巴厘岛旅拍', '&lt;p&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-07/590e69bba7efe.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-07/590e69bbc05a3.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-07/590e69bbc4bf4.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-07/590e69bbd3e28.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-07/590e69bbe9205.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-07/590e69bc03a28.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-07/590e69bc1e7df.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/www/mybysj.com/Public/Uploads/Blog/2017-05-07/590e69bc2ed9b.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '2017-05-07 08:27:14');

-- --------------------------------------------------------

--
-- 表的结构 `bs_content_img`
--

CREATE TABLE `bs_content_img` (
  `id` int(10) NOT NULL,
  `title` varchar(32) CHARACTER SET utf8 NOT NULL,
  `picUrl` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `picDes` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `sortid` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `bs_content_img`
--

INSERT INTO `bs_content_img` (`id`, `title`, `picUrl`, `picDes`, `sortid`) VALUES
(1, 'banner1', 'Public/Uploads/Lunbo/2017-05-05/590c0cf0cf220.jpg', 'dsfdsfs', 4),
(2, 'banner2', 'Public/Uploads/Lunbo/2017-05-07/590ecdafe4715.jpg', 'wwwwwwwwww', 1),
(4, 'banner3', 'Public/Uploads/Lunbo/2017-05-07/590ec06d191d1.jpg', 'banner3', 3);

-- --------------------------------------------------------

--
-- 表的结构 `bs_grapher`
--

CREATE TABLE `bs_grapher` (
  `id` int(6) NOT NULL,
  `face` varchar(255) NOT NULL,
  `username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `jieshao` varchar(20000) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `bs_grapher`
--

INSERT INTO `bs_grapher` (`id`, `face`, `username`, `jieshao`) VALUES
(1010, 'Public/Uploads/Face/2017-05-07/590ebacc42bfa.jpg', '大冰', '&lt;p&gt;测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数&lt;/p&gt;'),
(1014, 'Public/Uploads/Face/2017-05-06/590cc7bf46d14.jpg', 'sfsd', '&lt;p&gt;sdfdsfs&lt;/p&gt;'),
(1015, 'Public/Uploads/Face/2017-05-06/590dc7b7c5689.jpg', '邓丽君', '&lt;p&gt;测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据&lt;/p&gt;');

-- --------------------------------------------------------

--
-- 表的结构 `bs_images`
--

CREATE TABLE `bs_images` (
  `id` int(10) NOT NULL,
  `imgUrl` varchar(128) NOT NULL,
  `albumid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `bs_images`
--

INSERT INTO `bs_images` (`id`, `imgUrl`, `albumid`) VALUES
(10052, 'Public/Uploads/42017-05-07/590e0d6656f48.jpg', 4),
(10053, 'Public/Uploads/42017-05-07/590e0d666c70d.jpg', 4),
(10054, 'Public/Uploads/42017-05-07/590e0d6679230.jpg', 4),
(10055, 'Public/Uploads/42017-05-07/590e0d668596b.jpg', 4),
(10056, 'Public/Uploads/42017-05-07/590e0d6692c5e.jpg', 4),
(10057, 'Public/Uploads/42017-05-07/590e0d669dc28.jpg', 4),
(10090, 'Public/Uploads/42017-05-07/590e72d511660.jpg', 4),
(10091, 'Public/Uploads/52017-05-07/590e732e54132.jpg', 5),
(10092, 'Public/Uploads/62017-05-07/590ec60c1bdf5.png', 6),
(10093, 'Public/Uploads/62017-05-07/590ec60c40406.png', 6),
(10094, 'Public/Uploads/62017-05-07/590ec60c5a21c.png', 6),
(10095, 'Public/Uploads/62017-05-07/590ec60c7347a.png', 6),
(10096, 'Public/Uploads/62017-05-07/590ec60c87c9f.png', 6),
(10097, 'Public/Uploads/62017-05-07/590ec60c991fb.png', 6),
(10098, 'Public/Uploads/62017-05-07/590ec60ca97b7.png', 6),
(10099, 'Public/Uploads/62017-05-07/590ec60cb9d72.png', 6),
(10100, 'Public/Uploads/62017-05-07/590ec60cc9776.png', 6),
(10101, 'Public/Uploads/62017-05-07/590ec60ce3974.png', 6),
(10102, 'Public/Uploads/92017-05-07/590ecb3f6b4b2.png', 9),
(10103, 'Public/Uploads/92017-05-07/590ecb3f93d2b.png', 9),
(10104, 'Public/Uploads/92017-05-07/590ecb3fad759.png', 9),
(10105, 'Public/Uploads/92017-05-07/590ecb3fbd15d.png', 9),
(10106, 'Public/Uploads/92017-05-07/590ecb3fd5802.png', 9),
(10107, 'Public/Uploads/92017-05-07/590ecb3fe84cf.png', 9),
(10108, 'Public/Uploads/92017-05-07/590ecb401712f.png', 9),
(10109, 'Public/Uploads/92017-05-07/590ecb4058fee.png', 9),
(10110, 'Public/Uploads/92017-05-07/590ecb407ca47.png', 9),
(10111, 'Public/Uploads/92017-05-07/590ecb4096475.png', 9),
(10112, 'Public/Uploads/52017-05-07/590ecd7a01c01.jpg', 5),
(10113, 'Public/Uploads/52017-05-07/590ecd7a3b5ef.jpg', 5),
(10114, 'Public/Uploads/52017-05-07/590ecd7a5a60e.jpg', 5),
(10115, 'Public/Uploads/52017-05-07/590ecd7a72cb4.jpg', 5),
(10116, 'Public/Uploads/52017-05-07/590ecd7a86150.jpg', 5),
(10117, 'Public/Uploads/52017-05-07/590ecd7a9cc9e.jpg', 5),
(10118, 'Public/Uploads/52017-05-07/590ecd7ab9995.jpg', 5),
(10119, 'Public/Uploads/52017-05-07/590ecd7aca338.jpg', 5),
(10120, 'Public/Uploads/52017-05-07/590ecd7add3ed.jpg', 5),
(10121, 'Public/Uploads/52017-05-07/590ecd7af0c71.jpg', 5),
(10122, 'Public/Uploads/52017-05-07/590ecd7b0ef2e.jpg', 5);

-- --------------------------------------------------------

--
-- 表的结构 `bs_message`
--

CREATE TABLE `bs_message` (
  `id` int(5) NOT NULL,
  `blog_id` int(5) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `bs_message`
--

INSERT INTO `bs_message` (`id`, `blog_id`, `user_id`, `content`, `time`) VALUES
(10, 1002, 10003, '美', '2017-05-07 08:28:21'),
(11, 1002, 10002, '好看', '2017-05-07 14:37:49'),
(12, 1002, 10006, '很好看', '2017-05-07 14:38:28'),
(13, 1002, 10009, 'test11', '2017-05-07 15:19:36');

-- --------------------------------------------------------

--
-- 表的结构 `bs_user`
--

CREATE TABLE `bs_user` (
  `id` int(11) NOT NULL,
  `username` varchar(32) DEFAULT NULL,
  `email` varchar(128) NOT NULL,
  `tel` varchar(17) NOT NULL,
  `password` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `bs_user`
--

INSERT INTO `bs_user` (`id`, `username`, `email`, `tel`, `password`) VALUES
(10001, 'test1', '12345678@qq.com', '12345678900', '123456'),
(10002, 'test2', '77777777777@qq.com', '13560667985', '123456'),
(10003, 'test3', '12345478@qq.com', '13560446955', '123456'),
(10004, 'test4', '12345678#qq.com', '1234567890', '123456'),
(10006, 'test5', '2135525555@qq.com', '1235654885', '123456'),
(10009, 'test11', '445454545@qq.com', '454651231321', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bs_admin_user`
--
ALTER TABLE `bs_admin_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bs_album`
--
ALTER TABLE `bs_album`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bs_blog`
--
ALTER TABLE `bs_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bs_content_img`
--
ALTER TABLE `bs_content_img`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sortid` (`sortid`);

--
-- Indexes for table `bs_grapher`
--
ALTER TABLE `bs_grapher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bs_images`
--
ALTER TABLE `bs_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `albumid` (`albumid`);

--
-- Indexes for table `bs_message`
--
ALTER TABLE `bs_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bs_user`
--
ALTER TABLE `bs_user`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `bs_admin_user`
--
ALTER TABLE `bs_admin_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `bs_album`
--
ALTER TABLE `bs_album`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- 使用表AUTO_INCREMENT `bs_blog`
--
ALTER TABLE `bs_blog`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1003;
--
-- 使用表AUTO_INCREMENT `bs_content_img`
--
ALTER TABLE `bs_content_img`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- 使用表AUTO_INCREMENT `bs_grapher`
--
ALTER TABLE `bs_grapher`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1016;
--
-- 使用表AUTO_INCREMENT `bs_images`
--
ALTER TABLE `bs_images`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10123;
--
-- 使用表AUTO_INCREMENT `bs_message`
--
ALTER TABLE `bs_message`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- 使用表AUTO_INCREMENT `bs_user`
--
ALTER TABLE `bs_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10010;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

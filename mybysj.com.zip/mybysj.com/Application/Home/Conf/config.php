<?php
return array(
	//'配置项'=>'配置值'
	
    //设置url模式
    'URL_MODEL'=>1,
    
    //禁止缓存
    'TMPL_CACHE_ON' => false,
    'TMPL_CACHE_ON' => false,
    
    'TMPL_ACTION_ERROR' => 'Public:tips',
    //默认成功跳转对应的模板文件
    'TMPL_ACTION_SUCCESS' => 'Public:tips'
);
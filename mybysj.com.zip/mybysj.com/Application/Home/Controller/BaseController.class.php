<?php
namespace Home\Controller;
use Think\Controller;
class BaseController extends Controller {
	public $user;
	public function __construct() {
		parent::__construct();
		if(isset($_SESSION['user'])){
			$this->user = $_SESSION['user'];
			// dump($this->user);
			$this->assign("user",$this->user);
		}
	}
}

<?php
namespace Home\Controller;
use Think\Controller;
class GalleryController extends Controller {
    
    function gallery(){
        $this->display();
    }
}
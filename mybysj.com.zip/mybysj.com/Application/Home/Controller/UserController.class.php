<?php

namespace Home\Controller;
use Think\Controller;

class UserController extends Controller {
    //用户登录
    function login(){
        if (IS_POST) {
            $username = I("post.username");
            $userpwd = I("post.password");
            $verify = I("post.txtCode");
            $ret = $this->sverify($verify);
            if($ret['code']=="503"){
                $this->error($ret['msg'],U("login"));die;
            }
            $map['username'] = $username;
            $map['password'] = $userpwd;
            $data = M('user')->where($map)->find();
            if($data){
                $login_success['id'] = $data['id'];
                $login_success['username'] = $data['username'];
                $_SESSION['user'] = $login_success;
                $this->redirect("Home/index/index");die;
            }else{
                $this -> error('用户名或密码错误');die;
            }
        }
        $this->display();
    }
    
    //用户注册
    public function register(){
        if (IS_POST) {
            header("Content-Type:text/html; charset=utf-8");
    		$post = I("post.");
    		$data['username'] = $post['username'];
            $res = $this->checkuser($post['username']);
            if($res['code']=="503"){
                $this->error($res['msg'],U("register"));die;
            }
            $data['email'] = $post['email'];
            $res = $this->checkEmail($post['email']);
            if($res['code']=="503"){
                $this->error($res['msg'],U("register"));die;
            }
            $data['tel'] = $post['tel'];
            $res = $this->checkTel($post['tel']);
            if($res['code']=="503"){
                $this->error($res['msg'],U("register"));die;
            }
            $data['password'] = $post['password'];
            $res = $this->checkpassword($post['password'],$post['repassword']);
            if($res['code']=="503"){
                $this->error($res['msg'],U("register"));die;
            }
            $id = M('user')->add($data);
            if($id){
                 $login_success['id'] = $id;
                 $login_success['username'] = $data['username'];                 
                $this->redirect("/Home/user/login");die;
            }
    	}
    	$this->display();
    }
    
    private function checkuser($username){
        $map['username'] = array('eq',$username);
        $user = M('user')->where($map)->find();
        if($user){
            return array("code"=>"503","msg"=>"该用户名已存在!");
        }
    }
    private function checkEmail($email){
        $map['email'] = array('eq',$email);
        $email = M('user')->where($map)->find();
        if($email){
            return array("code"=>"503","msg"=>"该邮箱已注册!");
        }
    }
    private function checkTel($tel){
        $map['tel'] = array('eq',$tel);
        $tel = M('user')->where($map)->find();
        if($tel){
            return array("code"=>"503","msg"=>"该电话已被注册!");
        }
    }
    private function checkpassword($password,$repassword){
        if($password!==$repassword){
            return array('code'=>'503',"msg"=>"密码不一致");
        }
    }
    private function sverify($verify){
        $obj = new \Think\Verify();
        $checkverify = $obj->check($verify);
        if($checkverify==false){
            return array("code"=>503,"msg"=>"验证码错误");
        }
    
    }
    public function logout(){
        $_SESSION['user'] = null;
        session_unset();
        session_destroy();
        $this->redirect("Home/Index/index");
    }
    
    public function imgVerify(){
        $config = array(
            'length' => 3,
            'imageH' => 44,
            'imageW' => 90,
            'fontSize' => 14,
            'useNoise' => false,
            'fontttf' => '5.ttf',
        );
        $verify = new \Think\Verify($config);
        $verify->entry();
    }
}
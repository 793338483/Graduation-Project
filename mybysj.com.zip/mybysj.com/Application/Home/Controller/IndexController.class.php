<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends BaseController {
    public function __construct(){
        parent::__construct();
    }
    public function index(){
        //轮播图展示
        $adv = M("content_img")->order('sortid')->select();
        $this->assign("adv",$adv);
        $this->display();
    }
    
    public function photographers(){
        $gra = M("grapher")->select();
        $this->assign("grapher",$gra);
        $this->display();
    }
    public function  gallery(){
        $gallery = M('images')->where("albumid=4")->select();
        $this->assign("gal",$gallery);
        $this->display();
    }
    public function news(){
        $blog = M("blog")->where("id!=1001")->select();
        $this->assign("blog",$blog);
        $this->display();
    }
    public function news_show(){
        $id=I("get.id");
        $news = M("blog")->where("id=%d",$id)->find();
        $comment = M("message")->where("blog_id=%d",$id)->select();
        foreach ($comment as $key => $value){
            $user = M("user")->where("id=%d",$value['user_id'])->limit(1)->select();
            $comment[$key]['username']=$user[0]['username'];
        }
        $this->assign("commentlist",$comment);
        $this->assign("blog",$news);
        $this->display();
    }
    public function pinlun(){
        $id=I('get.blogid');
        if(IS_POST){
            $data['blog_id']=$id;
            $data['user_id']= $this->user['id'];
            $data['content']=I('post.comment-content');
            $data['time'] = date("Y-m-d H:i:s");
            $res = M("message")->add($data);
            if($res){
                $this->redirect("news_show",array('id'=>$id));
            }else{
                $this->success("评论失败");
            }
        }
    }
    public function userImages(){
        $userid= $this->user['id'];
        $a = M("album")->where("userID=%d",$userid)->find();
        if($a){
            $albumid = $a['id'];
            $img = M("images")->where("albumid=%d",$albumid)->select();
            $data['url'] =$img[0]['imgurl'];
        }
        $this->assign('url',$data);
        $this->assign("img",$img);
        $this->display();
    }
    
    //奖项
    public function award(){
        $title="1001";
        $rst =  M('blog')->where("id=%d",$title)->find();
        $this->assign("blog",$rst);
        $this->display();
    }
    public function userInfo(){
        $rst =  M('user')->where('id='.$this->user['id'])->find();
        $this->assign("person",$rst);
        $this->display();
    }
    public function changeInfo(){
        if(IS_POST){
            $data['username']=I('post.username');
            $data['email']=I("post.email");
            $data['tel']=I("post.tel");
            $res = M('user')->where('id='.$this->user['id'])->save($data);
            if($res){
                $this->success("修改成功");die;
            }else{
                $this->success("修改失败");die;
            }
        }
        $rst =  M('user')->where('id='.$this->user['id'])->find();
        $this->assign("person",$rst);
        $this->display();
    }
    
    public function download(){
        import('Org.Util.FileToZip');//引入zip下载类文件FileToZip
        // 打包下载
        $cur_file = 'Public/Download';
        $handler = opendir($cur_file); //$cur_file 文件所在目录
        $download_file = array();
        $i = 0;
        while( ($filename = readdir($handler)) !== false ) {
            if($filename != '.' && $filename != '..') {
                $download_file[$i++] = $filename;
            }
        }
        closedir($handler);
        $scandir=new traverseDir($cur_file,$save_path); //$save_path zip包文件目录
        $scandir->tozip($download_file);
    }
    //修改密码
    public function changePass(){
        if(IS_POST){
            $oldpass = I('post.oldPass');
            $userid = $this->user['id'];
            $rst = M('user')->where('id=%d and password=%s',array($userid,$oldpass))->find();
            if($rst!==false){
                $newpsw = I('post.newPass');
                $repsw = I('post.rePass');
                $res = $this->checkpassword($newpsw,$repsw);
                if($res['code']=='503'){
                    $this->success("密码不一致");die;
                }else{
                    $data['password']=$newpsw;
                    $rsts = M("user")->where('id='.$this->user['id'])->save($data);
                    if($rsts){
                        $this->success("修改成功");
                    }else{
                        $this->success("修改失败");
                    }
                }
            }      
        }else{
            $this->display();
        }
    }
    private function checkpassword($password,$repassword){
        if($password!==$repassword){
            return array('code'=>'503',"msg"=>"密码不一致");
        }
    }
    
}
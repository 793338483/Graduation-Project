<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<title>Home</title>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Stylish Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Custom Theme files -->
<link href="<?php echo (CSS_URL); ?>bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo (CSS_URL); ?>style.css" type="text/css" rel="stylesheet" media="all">
<link rel="stylesheet" href="<?php echo (CSS_URL); ?>flexslider.css" type="text/css" media="screen" />
<!-- js -->
<script src="<?php echo (JS_URL); ?>jquery-1.11.1.min.js"></script> 
<!-- //js -->	
<!-- start-smoth-scrolling-->
<script type="text/javascript" src="<?php echo (JS_URL); ?>move-top.js"></script>
<script type="text/javascript" src="<?php echo (JS_URL); ?>easing.js"></script>	
<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
</script>
<!--//end-smoth-scrolling-->
<!--pop-up-->
<script src="<?php echo (JS_URL); ?>menu_jquery.js"></script>
<!--//pop-up-->
</head>
<body>
	<!--header-->
	<div class="header">
		<div class="container">
			<div class="header-left">
				<?php if(empty($user)): ?><ul>
			  	 	<li><a href="/www/mybysj.com/index.php/Home/User/register.html">注册</a></li>
					<li><a href="/www/mybysj.com/index.php/Home/User/login.html">登录</a></li>
					</ul>
			  	 	<?php else: ?>
			  	 		<span> 欢迎您：<?php echo ($user['username']); ?></span>
			  	 		<a class="logout"  href="/www/mybysj.com/index.php/Home/User/logout">退出</a><?php endif; ?>
			</div>
			<div class="logo">
				<a href="index.html"> <img src="<?php echo (IMG_URL); ?>logo.png" alt=""/></a>
			</div>
			<div class="top-nav">
				<span class="menu"><img src="<?php echo (IMG_URL); ?>menu.png" alt=""/></span>
				<ul>
					<li><a class="active" href="/www/mybysj.com/index.php/Home/Index/index.html">首页</a></li>
					<li><a href="/www/mybysj.com/index.php/Home/Index/gallery.html">相集</a></li>					
					<li><a href="/www/mybysj.com/index.php/Home/Index/photographers.html">摄影师介绍</a></li>
					<li><a href="award.html">奖项</a></li>
					<li><a href="news.html">旅拍</a></li>
					<li><a href="/www/mybysj.com/index.php/Home/Index/contact.html">联系方式</a></li>
					<?php if($user['username']){ echo '<li><a href="/www/mybysj.com/index.php/Home/Index/person.html">个人中心</a></li>'; } ?>
				</ul>
				<!-- script-for-menu -->
				<script>					
							$("span.menu").click(function(){
								$(".top-nav ul").slideToggle("slow" , function(){
								});
							});
				</script>
				<!-- script-for-menu -->
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>	
	<!--//header-->
	<!--banner-->
	<div class="banner">
		<!-- banner-text Slider starts Here -->
		<script src="<?php echo (JS_URL); ?>responsiveslides.min.js"></script>
		<script>
			// You can also use "$(window).load(function() {"
				$(function () {
				// Slideshow 3
					$("#slider3").responsiveSlides({
					auto: true,
					pager:true,
					nav:true,
					speed: 500,
					namespace: "callbacks",
					before: function () {
					$('.events').append("<li>before event fired.</li>");
					},
					after: function () {
						$('.events').append("<li>after event fired.</li>");
					}
				});	
			});
		</script>
		<!--//End-slider-script -->
		<div  id="top" class="callbacks_container">
			<ul class="rslides" id="slider3">
			<?php if(is_array($adv)): foreach($adv as $ko=>$vo): ?><li>
		        	<div class="banner1">
		        		<img src="/www/mybysj.com/<?php echo ($vo["picurl"]); ?>">
		        	</div>
		        </li><?php endforeach; endif; ?>
			</ul>
			<div class="clearfix"> </div>
		</div>
	</div>			
	<!--//banner-->
	<!--banner-bottom-->
	<div class="banner-bottom">
		<div class="container">
			<div class="col-md-4 banner-bottom-grids">
				<h2>我们是谁？</h2>
			</div>
			<div class="col-md-8 banner-bottom-grids">
				
				<p>我们拥有业内资深摄影师、造型师、数码设计师等高水平、优质、创新的专业技术团队，
				一流的高端设备以及全心全意为客户提供精品服务的从业理念，
				我们旨在为客户打造真正高雅极具收藏价值的纪实婚礼纪念照。
				自成立以来，一直以优质的产品、完善的服务、健全的体制、最新的理念赢得了广大客户的赞誉和青睐，在全国纪实婚礼摄影市场有着举足轻重的作用。</p>
			</div>
			
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--//banner-bottom-->
	<!--work-->
	<div class="container">
	<div class="work">
		<div class="col-md-8 work-img">
			<img src="<?php echo (IMG_URL); ?>img28.jpg">			
		</div>
		<div class="col-md-4 work-grids">
			<h3>我们做什么?</h3>
			<p>以流行、专业、欢喜、诚心的宗旨服务于每一个客人，因为用心所以放心的经营理念、为每对新人创造美好记忆。
			实实在在的消费；真诚的品牌信誉；专业过硬的摄影技术；时尚靓丽的化妆造型；卓越的后期制作精致的美工设计；
			贴心的服务。新的生活、新的起点、新的观念，最爱以全新的一切为您编织美丽的梦！ </p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<div class="work2">		
		<div class="col-md-4 work-grids work-grids-left">
			<h3>为什么选择我们?</h3>
			<p>我们的优势有:</p>
			<ul>
				<li><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span><a href="#">1.高要求：从拍摄到后期采用100分制考核。</a></li>
				<li><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span><a href="#">2.高标准：“三无标准”无重拍，无模板，无投诉。</a></li>
				<li><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span><a href="#">3.高品质：高品质的专业水准，VIP尊贵礼遇。</a></li>
				<li><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span><a href="#">4.重口碑：顾客靠转介绍，我们经得起考验。</a></li>
				<li><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span><a href="#">5.重创新：追求艺术美的典范，让艺术与个性的升值。</a></li>
			</ul>

		</div>
		<div class="col-md-8 work-img work-img-btm">		
			<img src="<?php echo (IMG_URL); ?>img29.jpg">	
		</div>
		<div class="clearfix"> </div>
	</div>
	</div>
	<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-left">
				<p>Copyright &copy; 2017.Company name All rights reserved.</p>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--//footer-->
	<!--smooth-scrolling-of-move-up-->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!--//smooth-scrolling-of-move-up-->
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo (JS_URL); ?>bootstrap.js"></script>
</body>
</html>
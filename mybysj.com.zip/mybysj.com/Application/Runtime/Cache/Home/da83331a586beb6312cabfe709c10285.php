<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
<link href="<?php echo (CSS_URL); ?>bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo (CSS_URL); ?>style.css" type="text/css" rel="stylesheet" media="all">
<script src="<?php echo (JS_URL); ?>jquery-1.11.1.min.js"></script> 
</head>
<body>
	<div class="panel panel-default">
	  <div class="panel-heading">修改个人信息</div>
	  	<form class="user-form" method="post" action="/www/mybysj.com/index.php/Home/Index/changeInfo">
			<div class="form-group">
		        <div class="label">
		          <label>用户名：</label>
		        </div>
		        <div class="field">
		          <input type="text" class="input w50" value="<?php echo ($person["username"]); ?>" name="username" data-validate="required:请输入用户名" />
		          <div class="tips"></div>
		        </div>
		        <div class="clearfix"></div>
		     </div>
		     <div class="form-group">
		        <div class="label">
		          <label>个人邮箱：</label>
		        </div>
		        <div class="field">
		          <input type="text" class="input w50" value="<?php echo ($person["email"]); ?>" name="email" data-validate="required:请输入邮箱" />
		          <div class="tips"></div>
		        </div>
		        <div class="clearfix"></div>
		     </div>
		     <div class="form-group">
		        <div class="label">
		          <label>联系电话：</label>
		        </div>
		        <div class="field">
		          <input type="text" class="input w50" value="<?php echo ($person["tel"]); ?>" name="tel" data-validate="required:请输入电话" />
		          <div class="tips"></div>
		        </div>
		        <div class="clearfix"></div>
		     </div>
		     <div class="form-group">
		        <div class="label">
		          <label></label>
		        </div>
		        <div class="field">
		          <button class="btn btn-success" type="submit"> 提交</button>
		        </div>
		        <div class="clearfix"></div>
		      </div>
	  	</form>
	  	<div class="clearfix"></div>
	</div>

<script src="<?php echo (JS_URL); ?>bootstrap.js"></script>	
</body>
</html>
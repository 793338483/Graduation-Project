<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
<link href="<?php echo (CSS_URL); ?>bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo (CSS_URL); ?>style.css" type="text/css" rel="stylesheet" media="all">
<script src="<?php echo (JS_URL); ?>jquery-1.11.1.min.js"></script> 
</head>
<body>
	<div class="panel panel-default">
	  <div class="panel-heading">个人信息</div>
	  
	    <table class="table">
	    	<tr>
	    		<td>用户名：</td>
	    		<td><?php echo ($person["username"]); ?></td>
	    	</tr>
	    	<tr>
	    		<td>邮箱：</td>
	    		<td><?php echo ($person["email"]); ?></td>
	    	</tr>
	    	<tr>
	    		<td>电话：</td>
	    		<td><?php echo ($person["tel"]); ?></td>
	    	</tr>
	    </table>
	 
	</div>

<script src="<?php echo (JS_URL); ?>bootstrap.js"></script>	
</body>
</html>
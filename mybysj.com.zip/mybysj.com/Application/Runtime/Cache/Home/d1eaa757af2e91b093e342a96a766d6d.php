<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link href="<?php echo (CSS_URL); ?>bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo (CSS_URL); ?>style.css" type="text/css" rel="stylesheet" media="all">
<style>
	.gallery-grids ul{
		list-style:none;
	}
	.gallery-grids ul li{
		float:left;
		margin-right:1em;
		width:30%;
	}
	li img{
		max-width:100%;
	}
	.download{
		float:right;
		
	}
</style>
</head>
<body>
<div class="panel panel-default">
	  <div class="panel-heading">我的图片 <a href="/www/mybysj.com/Public/Download/52017-05-07.zip" class="download">下载图片</a></div>
	  <div class="panel-body">
	<div class="gallery-grids">
			<ul>
			<?php if(is_array($img)): foreach($img as $ko=>$vo): ?><li>
		        	<a>
						<img src="/www/mybysj.com/<?php echo ($vo["imgurl"]); ?>" alt="" />	
						<div class="glry-bgd">
						</div>
					</a>
		        	
		        </li><?php endforeach; endif; ?>
				</ul>
				</div>
				</div>
				</div>
				
</body>
</html>
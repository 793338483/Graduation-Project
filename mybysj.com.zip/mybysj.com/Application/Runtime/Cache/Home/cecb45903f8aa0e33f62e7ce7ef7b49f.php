<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<title>Home</title>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Stylish Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Custom Theme files -->
<link href="<?php echo (CSS_URL); ?>bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo (CSS_URL); ?>style.css" type="text/css" rel="stylesheet" media="all">
<link rel="stylesheet" href="<?php echo (CSS_URL); ?>flexslider.css" type="text/css" media="screen" />
<!-- js -->
<script src="<?php echo (JS_URL); ?>jquery-1.11.1.min.js"></script> 
<!-- //js -->	
<!-- start-smoth-scrolling-->
<script type="text/javascript" src="<?php echo (JS_URL); ?>move-top.js"></script>
<script type="text/javascript" src="<?php echo (JS_URL); ?>easing.js"></script>	
<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
</script>
<!--//end-smoth-scrolling-->
<!--pop-up-->
<script src="<?php echo (JS_URL); ?>menu_jquery.js"></script>
<!--//pop-up-->
</head>
<body>
	<!--header-->
	<div class="header">
		<div class="container">
			<div class="header-left">
				<?php if(empty($user)): ?><ul>
			  	 	<li><a href="/www/mybysj.com/index.php/Home/User/register.html">注册</a></li>
					<li><a href="/www/mybysj.com/index.php/Home/User/login.html">登录</a></li>
					</ul>
			  	 	<?php else: ?>
			  	 		<span> 欢迎您：<?php echo ($user['username']); ?></span>
			  	 		<a class="logout"  href="/www/mybysj.com/index.php/Home/User/logout">退出</a><?php endif; ?>
			</div>
			<div class="logo">
				<a href="index.html"> <img src="<?php echo (IMG_URL); ?>logo.png" alt=""/></a>
			</div>
			<div class="top-nav">
				<span class="menu"><img src="<?php echo (IMG_URL); ?>menu.png" alt=""/></span>
				<ul>
					<li><a href="/www/mybysj.com/index.php/Home/Index/index.html">首页</a></li>
					<li><a href="/www/mybysj.com/index.php/Home/Index/gallery.html">相集</a></li>					
					<li><a href="/www/mybysj.com/index.php/Home/Index/photographers.html">摄影师介绍</a></li>
					<li><a href="award.html">奖项</a></li>
					<li><a class="active" href="news.html">旅拍</a></li>
					<li><a href="/www/mybysj.com/index.php/Home/Index/contact.html">联系方式</a></li>
					<?php if($user['username']){ echo '<li><a class="active" href="/www/mybysj.com/index.php/Home/Index/person.html">个人中心</a></li>'; } ?>
				</ul>
				<!-- script-for-menu -->
				<script>					
							$("span.menu").click(function(){
								$(".top-nav ul").slideToggle("slow" , function(){
								});
							});
				</script>
				<!-- script-for-menu -->
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>	
	<!--//header-->
	<!--banner-->
	<div class="banner1 about-bnr">
	</div>	
	<!--//banner-->
	<!--news-->
	<div class="news">
		<div class="container">
			<div class="news-info">   
        		<?php if(is_array($blog)): foreach($blog as $ko=>$vo): ?><div class="col-md-12 news-grids">
						<div class="news-grids-left">
							<img class="blog_cover"src="/www/mybysj.com/<?php echo ($vo["blog_img"]); ?>" class="img-responsive" alt="/">
						</div>
						<div class="news-grids-right">
							<h5> <a href="/www/mybysj.com/index.php/Home/Index/news_show/id/<?php echo ($vo["id"]); ?>"><?php echo ($vo["blog_title"]); ?></a></h5>
							<p><?php echo ($vo["blog_zhaiyao"]); ?></p>
						</div>
						<div class="clearfix"> </div>
					</div><?php endforeach; endif; ?> 
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!--//news-->
	<!--footer-->
	<div class="footer">
		<div class="container">
			<div class="footer-left">
				<p>Copyright &copy; 2017.Company name All rights reserved.</p>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--//footer-->
	<!--smooth-scrolling-of-move-up-->
	<script type="text/javascript">
		$(document).ready(function() {
			$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
    <script src="<?php echo (JS_URL); ?>bootstrap.js"></script>
</body>
</html>
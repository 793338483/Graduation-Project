<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
<link href="<?php echo (CSS_URL); ?>bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo (CSS_URL); ?>style.css" type="text/css" rel="stylesheet" media="all">
<script src="<?php echo (JS_URL); ?>jquery-1.11.1.min.js"></script> 
</head>
<body>
	<div class="panel panel-default">
	  <div class="panel-heading">修改个人密码</div>
	  	<form class="user-form" action="/www/mybysj.com/index.php/Home/Index/changePass" method="post" >
			<div class="form-group">
		        <div class="label">
		          <label>原密码：</label>
		        </div>
		        <div class="field">
		          <input type="password" class="input w50"name="oldPass" data-validate="required:请输入原密码" />
		          <div class="tips"></div>
		        </div>
		        <div class="clearfix"></div>
		     </div>
		     <div class="form-group">
		        <div class="label">
		          <label>新密码：</label>
		        </div>
		        <div class="field">
		          <input type="password" class="input w50"name="newPass" data-validate="required:请输入密码" />
		          <div class="tips"></div>
		        </div>
		        <div class="clearfix"></div>
		     </div>
		     <div class="form-group">
		        <div class="label">
		          <label>确认密码：</label>
		        </div>
		        <div class="field">
		          <input type="password" class="input w50" name="rePass" data-validate="required:请确认密码" />
		          <div class="tips"></div>
		        </div>
		        <div class="clearfix"></div>
		     </div>
		     <div class="form-group">
		        <div class="label">
		          <label></label>
		        </div>
		        <div class="field">
		          <button class="btn btn-success" type="submit"> 确认修改</button>
		        </div>
		      </div>
	  	</form>
	  	<div class="clearfix"></div>
	</div>

<script src="<?php echo (JS_URL); ?>bootstrap.js"></script>	
</body>
</html>
<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="<?php echo (ADMIN_CSS_URL); ?>pintuer.css">
<link rel="stylesheet" href="<?php echo (ADMIN_CSS_URL); ?>admin.css">
<script src="<?php echo (ADMIN_JS_URL); ?>jquery.js"></script>
<script src="<?php echo (ADMIN_JS_URL); ?>pintuer.js"></script>
</head>
<body>
<div class="panel admin-panel">
  <div class="panel-head"><strong class="icon-reorder"> 内容列表</strong></div>
  <div class="padding border-bottom">  
  <button type="button" class="button border-yellow" onclick="window.location.href='/www/mybysj.com/index.php/Admin/Index/addAdv.html'" target="right"><span class="icon-plus-square-o"></span> 添加内容</button>
  </div>
  <table class="table table-hover text-center">
    <tr>
      <th width="10%">ID</th>
      <th width="20%">图片</th>
      <th width="15%">名称</th>
      <th width="20%">描述</th>
      <th width="10%">排序</th>
      <th width="15%">操作</th>
    </tr>
   <?php if(is_array($adv)): foreach($adv as $ko=>$vo): ?><tr>
          <td><?php echo ($vo["id"]); ?></td>
          <td><img class="lunbo_img"src="/www/mybysj.com/<?php echo ($vo["picurl"]); ?>"></td>
          <td><?php echo ($vo["title"]); ?></td>
          <td><?php echo ($vo["picdes"]); ?></td>
          <td><?php echo ($vo["sortid"]); ?></td>
          <td><div class="button-group"> <a class="button border-main" href="/www/mybysj.com/index.php/Admin/Index/addAdv/id/<?php echo ($vo["id"]); ?>"><span class="icon-edit"></span> 修改</a> <a class="button border-red" href="javascript:void(0)" onclick="return del(<?php echo ($vo["id"]); ?>,2)"><span class="icon-trash-o"></span> 删除</a> </div></td>
        </tr><?php endforeach; endif; ?>
      <tr>
        <td colspan="8"><div class="sabrosus"><?php echo ($page); ?></div></td>
      </tr>
  </table>
</div>
<script type="text/javascript">
function del(id,type){
	if(confirm("您确定要删除吗?")){
		$.post("/www/mybysj.com/index.php/Admin/Index/del",{id:id,type:type},function(msg){
		      if(msg==1){
		        window.location.href="";
		      }
	    	})
	}
}
</script>
</body></html>
<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="<?php echo (ADMIN_CSS_URL); ?>pintuer.css">
<link rel="stylesheet" href="<?php echo (ADMIN_CSS_URL); ?>admin.css">
<script src="<?php echo (ADMIN_JS_URL); ?>jquery.js"></script>
<script src="<?php echo (ADMIN_JS_URL); ?>pintuer.js"></script>
</head>
<body>
<div class="panel admin-panel margin-top" id="add">
  <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 添加旅拍</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="/www/mybysj.com/index.php/Admin/Index/addBlog/id/3" enctype="multipart/form-data">    
      <div class="form-group">
        <div class="label">
          <label>标题：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="<?php echo ($blog["blog_title"]); ?>" name="blog_title" data-validate="required:请输入标题" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>摘要：</label>
        </div>
        <div class="field">
          <textarea type="text" class="input" name="zhaiyao" style="height:120px;"><?php echo ($blog["blog_zhaiyao"]); ?></textarea>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>内容：</label>
        </div>
        <div class="field">
          <textarea type="text" id="uEditor"class="input" name="content" data-validate="required:请输入内容"><?php echo ($blog["blog_content"]); ?></textarea>
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>预览图：</label>
        </div>
        <div class="field">
          <input type="file" name="thumbnail"/>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
        </div>
      </div>
    </form>
  </div>
</div>
<script type="text/javascript" src="/www/mybysj.com/Public/UEditor/ueditor.config.js"></script>
<script type="text/javascript" src="/www/mybysj.com/Public/UEditor/ueditor.all.min.js"></script>
<script type="text/javascript" src="/www/mybysj.com/Public/UEditor/lang/zh-cn/zh-cn.js"></script>
<script type="text/javascript">
	window.UEDITOR_HOME_URL = '/www/mybysj.com/Public/UEditor/'; // 添加编辑器实例所在的路径
    $(function(){
    	UE.getEditor('uEditor',{
    		toolbars:[[ 'undo', 'redo', '|',
    		            'bold', 'italic', 'underline', 'fontborder', 'strikethrough', 'superscript', 'subscript', 'removeformat', 'formatmatch', 
    		            'autotypeset', 'blockquote', 'pasteplain', '|', 'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc', '|',
    		            'rowspacingtop', 'rowspacingbottom', 'lineheight', '|',
    		            'customstyle', 'paragraph', 'fontfamily', 'fontsize', '|',
    		            'directionalityltr', 'directionalityrtl', 'indent', '|',
    		            'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|', 'touppercase', 'tolowercase', '|',
    		            'simpleupload', 'insertimage', 'emotion', 'scrawl','attachment',  'background', '|',
    		            'horizontal']],
    		initialFrameWidth:1090,
    		initialFrameHeight:600,
    		serverUrl:"<?php echo U(Admin. '/Index/upload');?>"
    	})
    })
    
</script> 
</body>
</html>
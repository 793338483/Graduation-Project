<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta name="renderer" content="webkit">
<title></title>
<link rel="stylesheet" href="<?php echo (ADMIN_CSS_URL); ?>pintuer.css">
<link rel="stylesheet" href="<?php echo (ADMIN_CSS_URL); ?>admin.css">
<script src="<?php echo (ADMIN_JS_URL); ?>jquery.js"></script>
<script src="<?php echo (ADMIN_JS_URL); ?>pintuer.js"></script>
</head>
<body>
<div class="panel admin-panel margin-top" id="add">
  <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 添加摄影师信息</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="/www/mybysj.com/index.php/Admin/Index/addgrapher/id/1010" enctype="multipart/form-data">    
      <div class="form-group">
        <div class="label">
          <label>姓名：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="<?php echo ($grapher["username"]); ?>" name="username" data-validate="required:请输入姓名" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>图片：</label>
        </div>
        <div class="field">
          <input type="file" name="face"/>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>介绍：</label>
        </div>
        <div class="field">
          <textarea type="text" id="uEditor"class="input" name="jieshao" style="height:120px;" value="<?php echo ($grapher["jieshao"]); ?>"><?php echo ($grapher["jieshao"]); ?></textarea>
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
        </div>
      </div>
    </form>
  </div>
</div>
<script type="text/javascript" src="/www/mybysj.com/Public/UEditor/ueditor.config.js"></script>
<script type="text/javascript" src="/www/mybysj.com/Public/UEditor/ueditor.all.min.js"></script>
<script type="text/javascript" src="/www/mybysj.com/Public/UEditor/lang/zh-cn/zh-cn.js"></script>
<script type="text/javascript">
    window.UEDITOR_HOME_URL = '/www/mybysj.com/Public/UEditor/'; // 添加编辑器实例所在的路径
    window.onload = function(){
    	$(function(){
        	UE.getEditor('uEditor',{
        		toolbars:[['undo','redo','bold', 'italic',
        		           'underline','fontsize','justifyleft', 'justifyright','justifycenter', 'justifyjustify']],
        		initialFrameWidth:1090,
        		initialFrameHeight:300,
        		serverUrl:"<?php echo U(Admin.'/Index/index/upload');?>",
        		maximumWords:1000,
        		enableAutoSave: false,
        		autoSyncData: false
        	});
        })
    }
</script> 
</body>
</html>
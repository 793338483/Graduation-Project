<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title>网站信息</title>  
    <link rel="stylesheet" href="<?php echo (ADMIN_CSS_URL); ?>pintuer.css">
    <link rel="stylesheet" href="<?php echo (ADMIN_CSS_URL); ?>admin.css">
    <script src="<?php echo (ADMIN_JS_URL); ?>jquery.js"></script>
    <script src="<?php echo (ADMIN_JS_URL); ?>pintuer.js"></script>  
</head>
<body>
<div class="panel admin-panel">
  <div class="panel-head"><strong class="icon-reorder"> 用户列表</strong></div>
  <table class="table table-hover text-center">
    <tr>
      <th width="10%">用户ID</th>
      <th width="15%">用户名</th>
      <th width="30%">邮箱</th>
      <th width="30%">联系方式</th>
      <th width="15%">操作</th>
    </tr>
   <?php if(is_array($user)): foreach($user as $ko=>$vo): ?><tr>
          <td><?php echo ($vo["id"]); ?></td>
          <td><?php echo ($vo["username"]); ?></td>
          <td><?php echo ($vo["email"]); ?></td>
          <td><?php echo ($vo["tel"]); ?></td>
          <td><div class="button-group"> <a class="button border-red" href="javascript:void(0)" onclick="return del(<?php echo ($vo["id"]); ?>,1)"><span class="icon-trash-o"></span> 删除</a> </div></td>
        </tr><?php endforeach; endif; ?>
      <tr>
        <td colspan="8"><div class="sabrosus"><?php echo ($page); ?></div></td>
      </tr>
  </table>
</div>
<script>
function del(id,type){
	if(confirm("您确定要删除吗?")){
		$.post("/www/mybysj.com/index.php/Admin/Index/del",{id:id,type:type},function(msg){
		      if(msg==1){
		        window.location.href="";
		      }
	    	})
	}
}
</script>
</body></html>
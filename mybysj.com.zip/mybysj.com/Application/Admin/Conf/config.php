<?php
return array(
	//'配置项'=>'配置值'
	////默认错误跳转对应的模板文件
	'TMPL_ACTION_ERROR' => 'Public:tips',
	//默认成功跳转对应的模板文件
	'TMPL_ACTION_SUCCESS' => 'Public:tips'
);
<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends BaseController {
    public function __construct(){
        parent::__construct();
    }
    
    //轮播图列表
    public function adv(){
        $count = M("content_img")->count();
        $Page = new \Think\Page($count,6);
        $adv = M("content_img")->limit($Page->firstRow.','.$Page->listRows)->order('sortid')->select();
        $Page->setConfig('next', '下一页');
        $Page->setConfig('prev', '上一页');
        $show = $Page->show(); // 分页显示输出
        $this->assign('page', urldecode($show)); // 赋值分页输出
        $this->assign("adv",$adv);
        $this->display();
    }
    //添加轮播图
    public function addAdv(){
        $id = I("get.id");
        if(IS_POST){
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath  =      './Public/Uploads/Lunbo/'; // 设置附件上传根目录
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            $info   =   $upload->upload();
            $savepath = $info['picUrl']['savepath'].$info['picUrl']['savename'];
            $data['title'] = I("post.title");
            $imgurl = "Public/Uploads/Lunbo/".$savepath;
            $data['picUrl'] = $imgurl;
            $data['picDes'] = I('post.picDes');
            $data['sortid'] = I("post.sortid");
            if($id){
                $checkID = M("content_img")->where("sortid=%d and id!=%d",array($data['sortid'],$id))->find();
                if($checkID){
                    $this->error("修改失败",U("adv"));die;
                }else{
                    $res = M("content_img")->where("id=%d",$id)->save($data);
                    if($res!==false||$res!==0){
                        $this->success("修改成功",U("adv"));die;
                    }else{
                        $this->error("修改失败",U("adv"));die;
                    }
                }
                
            }else{
                $res = M("content_img")->add($data);
                if($res){
                    $this->success("添加成功",U("adv"));die;
                 }else{
                    $this->error("添加失败",U("adv"));die;
                }
            }
        }
        $adv = M("content_img")->where("id=%d",$id)->find();
        $this->assign("adv",$adv);
        $this->display();
    }
    //相册图片详情
    public function imglist(){
        $albumid=I('get.id');
        $data['albumid']=$albumid;
        $imglist = M('images')->where("albumid=%d",$albumid)->select();
        $this->assign("album",$data);
        $this->assign("imglist",$imglist);
        $this->display();
    }
    public function addImg(){
        
        $albumid=I('get.id');
        $data['id'] = $albumid;
        if(IS_POST){
            $aid=$_SERVER['HTTP_REFERER'];
            $int = strrpos($aid,'/')+1;
            $album = substr($aid,$int);
            $config = array(
                'mimes'         =>  array(), //允许上传的文件MiMe类型
                'maxSize'       =>  0, //上传的文件大小限制 (0-不做限制)
                'exts'          =>  array('jpg', 'gif', 'png', 'jpeg'), //允许上传的文件后缀
                'autoSub'       =>  true, //自动子目录保存文件
                'subName'       =>  array('date', 'Y-m-d'), //子目录创建方式，[0]-函数名，[1]-参数，多个参数使用数组
                'rootPath'      =>  './Public/Uploads/', //保存根路径
                'savePath'      =>  $album,//保存路径
            );
            $upload = new \Think\Upload($config);// 实例化上传类
            $info   =   $upload->upload();
            if(!$info) {
                 
                $this->error($upload->getError());// 上传错误提示错误信息
                 
            }else{// 上传成功
                foreach ($info as $va){
                    $savepath = "Public/Uploads/".$va['savepath'].$va['savename'];
                    $data['imgUrl']=$savepath;
                    $data['albumid']=$album;
                    $res = M("images")->add($data);
                }
            }
        }
        $this->assign("imglist",$data);
        $this->display();
        
     
    }
    //摄影师管理
    public function grapher(){
        $count = M("grapher")->count();
        $Page = new \Think\Page($count,3);
        $grapher = M("grapher")->limit($Page->firstRow.','.$Page->listRows)->select();
        $Page->setConfig('next', '下一页');
        $Page->setConfig('prev', '上一页');
        $show = $Page->show(); // 分页显示输出
        $this->assign('page', urldecode($show)); // 赋值分页输出
        $this->assign("grapher",$grapher);
        $this->display();
    }
    public function addgrapher(){
        $id = I("get.id");
        if(IS_POST){
            $data['username'] = I("post.username");
            $data['jieshao'] = htmlspecialchars(stripslashes($_POST['jieshao']));;
            $upload = new \Think\Upload();
            $upload->maxSize = 3145728;
            $upload->allowExts = array('jpg','gif','png','jpeg');
            $upload->rootPath   = "./Public/Uploads/Face/";
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            $upload->saveRule = "time";
            $info = $upload->upload();
            $savepath = $info['face']['savepath'].$info['face']['savename'];
            $face = "Public/Uploads/Face/".$savepath;
            $data['face']=$face;
            if($id){
                $res = M("grapher")->where("id=%d",$id)->save($data);
                if($res){
                    $this->success("修改成功",U("grapher"));die;
                }else{
                    $this->error("修改失败",U("grapher"));die;
                }
            }else{
                $res = M("grapher")->add($data);
                if($res){
                    $this->success("添加成功",U("grapher"));die;
                }else{
                    $this->error("添加失败",U("grapher"));die;
                }
            }
       }
        $grapher = M("grapher")->where("id=%d",$id)->find();
        $this->assign("grapher",$grapher);
        $this->display();
    }
    
    
    //相集管理
    public function albumlist(){
        $count = M("album")->count();
        $Page = new \Think\Page($count,12);
        $album = M("album")->limit($Page->firstRow.','.$Page->listRows)->select();
        $Page->setConfig('next', '下一页');
        $Page->setConfig('prev', '上一页');
        $show = $Page->show(); // 分页显示输出
        $this->assign('page', urldecode($show)); // 赋值分页输出
        $this->assign("album",$album);
        $this->display();
    }
    public function addAlbum(){
        if(IS_POST){
            $data['albumname'] = I("post.albumname");
            $upload = new \Think\Upload();
            $upload->maxSize = 3145728;
            $upload->allowExts = array('jpg','gif','png','jpeg');
            $upload->rootPath   = "./Public/Uploads/Albums/";
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            $upload->saveRule = "time";
            $info = $upload->upload();
            $savepath = $info['albumimg']['savepath'].$info['albumimg']['savename'];
            $face = "Public/Uploads/Albums/".$savepath;
            $data['albumimg']=$face;
            $data['userID'] = I("post.userID");
            $res = M("album")->add($data);
            if($res){
                $this->success("添加成功",U("albumlist"));die;
            }else{
                $this->error("添加失败",U("albumlist"));die;
            }   
        }
         $this->display();
    }
    
    
    
    
    public function upload(){
        $ueditor_config = json_decode(preg_replace("/\/\*[\s\S]+?\*\//", "", file_get_contents("./Public/Ueditor/php/config.json")), true);
        $action = $_GET['action'];
        
        switch ($action) {
            case 'config':
                $result =  json_encode($ueditor_config);
                break;
        
                /* 上传图片 */
            case 'uploadimage':
                /* 上传涂鸦 */
            case 'uploadscrawl':
                /* 上传视频 */
            case 'uploadvideo':
                /* 上传文件 */
            case 'uploadfile':
                $upload = new \Think\Upload();
                $upload->maxSize = 3145728;
                $upload->rootPath = './Public/Uploads/Blog/';
                $upload->exts = array('jpg', 'gif', 'png', 'jpeg');
                $info = $upload->upload();
                if (!$info) {
                    $result = json_encode(array(
                        'state' => $upload->getError(),
                    ));
                } else {
                    $url = __ROOT__ . "/Public/Uploads/Blog/" . $info["upfile"]["savepath"] . $info["upfile"]['savename'];
                    $result = json_encode(array(
                        'url' => $url,
                        'title' => htmlspecialchars($_POST['pictitle'], ENT_QUOTES),
                        'original' => $info["upfile"]['name'],
                        'state' => 'SUCCESS'
                    ));
                }
                break;
        
            default:
                $result = json_encode(array(
                'state'=> '请求地址出错'
                    ));
                    break;
        }
        
        /* 输出结果 */
        if (isset($_GET["callback"])) {
            if (preg_match("/^[\w_]+$/", $_GET["callback"])) {
                echo htmlspecialchars($_GET["callback"]) . '(' . $result . ')';
            } else {
                echo json_encode(array(
                    'state'=> 'callback参数不合法'
                ));
            }
        } else {
            echo $result;
        }
    }
    //用户管理
    public function usermanage(){
        $count = M("user")->count();
        $Page = new \Think\Page($count,10);
        $user = M("user")->limit($Page->firstRow.','.$Page->listRows)->select();
        $Page->setConfig('next', '下一页');
        $Page->setConfig('prev', '上一页');
        $show = $Page->show(); // 分页显示输出
        $this->assign('page', urldecode($show)); // 赋值分页输出
        $this->assign("user",$user);
        $this->display();
    }
    
    //1、删除用户，2、删除轮播图，3、删除摄影师信息，4、删除相集，5、删除相片，6、删除旅拍文章
    public function del(){
        $id = I("post.id");
    	$type = I("post.type");
    	switch ($type) {
    		case '1':
    		    $pl = M('message')->where("user_id=%d",$id)->delete();
    		    $i = M("album")->where("userID=%d",$id)->find();
    		    $imgid = $i['id'];
    		    $ds = M("images")->where("albumid=%d",$imgid)->delete();
    		    $res = M("album")->where("userID=%d",$id)->delete();
    		    
    			$rest = M("user")->where("id=%d",$id)->delete();
    			break;
    		case '2':
    			$res = M("content_img")->where("id=%d",$id)->delete();
    			break;
            case '3':
                $res = M("grapher")->where("id=%d",$id)->delete();
                break;
            case '4':
                $d = M("images")->where("album=%d",$id)->delete();
                $res = M("album")->where("id=%d",$id)->delete();
                break;
            case '5':
                $res = M("images")->where("id=%d",$id)->delete();
                break;
            case '6':
                $p = M('message')->where("blog_id=%d",$id)->delete();
                $res = M('blog')->where("id=%d",$id)->delete();
    	}
    	if($res){
    		$this->ajaxReturn("1");
    	}
    }
    //旅拍管理
    public function lvpai(){
        $count = M("blog")->count();
        $Page = new \Think\Page($count,10);
        $blog = M("blog")->limit($Page->firstRow.','.$Page->listRows)->select();
        $Page->setConfig('next', '下一页');
        $Page->setConfig('prev', '上一页');
        $show = $Page->show(); // 分页显示输出
        $this->assign('page', urldecode($show)); // 赋值分页输出
        $this->assign("blog",$blog);
        $this->display();
    }
     
    public function addBlog(){
       $id = I("get.id");
        if(IS_POST){
            $data['blog_title'] = I("post.blog_title");
            $data['blog_zhaiyao']=I("post.zhaiyao");
            $data['blog_content'] = htmlspecialchars(stripslashes($_POST['content']));;
            $upload = new \Think\Upload();
            $upload->maxSize = 3145728;
            $upload->allowExts = array('jpg','gif','png','jpeg');
            $upload->rootPath   = "./Public/Uploads/Blog/";
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            $upload->saveRule = "time";
            $info = $upload->upload();
            $savepath = $info['thumbnail']['savepath'].$info['thumbnail']['savename'];
            $thumbnail = "Public/Uploads/Blog/".$savepath;
            $data['blog_img']=$thumbnail;
            $data['addtime'] = date("Y-m-d H:i:s",time());
            if($id){
                $res = M("blog")->where("id=%d",$id)->save($data);
                if($res){
                    $this->success("修改成功",U("lvpai"));die;
                }else{
                    $this->error("修改失败",U("lvpai"));die;
                }
            }else{
                $res = M("blog")->add($data);
                if($res){
                    $this->success("添加成功",U("lvpai"));die;
                }else{
                    $this->error("添加失败",U("lvpai"));die;
                }
            }
         }
        $blog = M("blog")->where("id=%d",$id)->find();
        $this->assign("blog",$blog);
        $this->display();
    }
    
    //修改密码
    public function pass(){
        if(IS_POST){
            $oldpass = I('post.mpass');
            $userid = $this->user['id'];
            $rst = M('admin_user')->where('id=%d and password=%s',array($userid,$oldpass))->find();
            if($rst!==false){
                $newpsw = I('post.newpass');
                $repsw = I('post.renewpass');
                $res = $this->checkpassword($newpsw,$repsw);
                if($res['code']=='503'){
                    $this->success("密码不一致");die;
                }else{
                    $data['password']=$newpsw;
                    $rsts = M("admin_user")->where('id='.$this->user['id'])->save($data);
                    if($rsts){
                        $this->success("修改成功");
                    }else{
                        $this->success("修改失败");
                    }
                }
            }
        }else{
            $this->display();
        }
    }
    private function checkpassword($password,$repassword){
        if($password!==$repassword){
            return array('code'=>'503',"msg"=>"密码不一致");
        }
    }
    
    function index(){
        $this->display();
    }
    
}